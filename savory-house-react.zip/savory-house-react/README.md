# Savory House – Restaurant Website

A modern, fully responsive restaurant website built with **React + Vite**.

## Features

- Beautiful hero section
- About section with stats
- Interactive menu with category filtering (All, Nigerian, Continental, Grill, Healthy, Dessert)
- Reservation / contact form
- Fully responsive (mobile + desktop)
- Smooth scrolling navigation
- Clean, elegant restaurant design

## Quick Start

### 1. Install dependencies

```bash
npm install
```

### 2. Run the development server

```bash
npm run dev
```

Open the link shown in the terminal (usually `http://localhost:5173`)

### 3. Build for production

```bash
npm run build
```

---

## How to put it on GitHub

1. Create a new repository on GitHub (e.g. `savory-house-react`)
2. In the project folder, run:

```bash
git init
git add .
git commit -m "Initial commit - Savory House restaurant website"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/savory-house-react.git
git push -u origin main
```

---

## How to Host it (Free)

### Option 1: Vercel (Recommended)

1. Go to [vercel.com](https://vercel.com) and sign in with GitHub
2. Click **Add New Project**
3. Import your `savory-house-react` repository
4. Click **Deploy**
5. Your site will be live in under a minute

### Option 2: Netlify

1. Go to [netlify.com](https://netlify.com)
2. Drag and drop the `dist` folder (after running `npm run build`)  
   **or** connect your GitHub repo

---

## Project Structure

```
savory-house-react/
├── index.html
├── package.json
├── vite.config.js
├── src/
│   ├── App.jsx          ← Main application
│   ├── main.jsx
│   └── index.css        ← All styles
└── README.md
```

## Customisation

- Menu items are in `src/App.jsx` (the `menuItems` array)
- Colours and fonts are in `src/index.css` (`:root` variables)
- Change restaurant name, address, phone, etc. directly in `App.jsx`

---

Made with ❤️ for Savory House
