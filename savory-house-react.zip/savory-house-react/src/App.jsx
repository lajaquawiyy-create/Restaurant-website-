import { useState, useEffect } from 'react'
import { Menu, X, MapPin, Phone, Clock, Mail, ChefHat, Star, Users } from 'lucide-react'

const menuItems = [
  {
    id: 1,
    name: 'House Beef Burger',
    category: 'Grill',
    price: '₦7,000',
    description: 'Juicy grilled beef, fresh lettuce, tomato and our signature house sauce on a toasted brioche bun.',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=600&q=80'
  },
  {
    id: 2,
    name: 'Creamy Chicken Pasta',
    category: 'Continental',
    price: '₦9,000',
    description: 'Tender chicken tossed in a silky, herb-infused cream sauce with fettuccine and parmesan.',
    image: 'https://images.unsplash.com/photo-1621996346565-e3dbc646d9a9?w=600&q=80'
  },
  {
    id: 3,
    name: 'Grilled Fish & Plantain',
    category: 'Nigerian',
    price: '₦12,000',
    description: 'Char-grilled fish with sweet plantain and spicy pepper sauce. A true Nigerian classic.',
    image: 'https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=600&q=80'
  },
  {
    id: 4,
    name: 'Garden Fresh Salad',
    category: 'Healthy',
    price: '₦6,500',
    description: 'Crisp greens, seasonal vegetables and citrus dressing. Light, refreshing and full of flavour.',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80'
  },
  {
    id: 5,
    name: 'Chocolate Dessert',
    category: 'Dessert',
    price: '₦5,000',
    description: 'A rich chocolate treat to finish your meal on a high note. Decadent and unforgettable.',
    image: 'https://images.unsplash.com/photo-1578985545062-69928b1d9587?w=600&q=80'
  },
  {
    id: 6,
    name: 'Jollof Rice Special',
    category: 'Nigerian',
    price: '₦8,500',
    description: 'Smoky party-style jollof rice served with grilled chicken and fried plantain.',
    image: 'https://images.unsplash.com/photo-1604329760661-e71dc83f8f26?w=600&q=80'
  },
  {
    id: 7,
    name: 'Grilled Chicken Wings',
    category: 'Grill',
    price: '₦6,000',
    description: 'Crispy grilled wings tossed in our house spicy glaze. Perfect for sharing.',
    image: 'https://images.unsplash.com/photo-1527477396000-e2714b90eeab?w=600&q=80'
  },
  {
    id: 8,
    name: 'Beef Stroganoff',
    category: 'Continental',
    price: '₦11,000',
    description: 'Tender strips of beef in a creamy mushroom sauce, served over buttery egg noodles.',
    image: 'https://images.unsplash.com/photo-1604908176997-125f25cc6f3d?w=600&q=80'
  },
  {
    id: 9,
    name: 'Avocado Power Bowl',
    category: 'Healthy',
    price: '₦7,500',
    description: 'Quinoa, avocado, roasted veggies, chickpeas and a zesty lemon tahini dressing.',
    image: 'https://images.unsplash.com/photo-1512621776951-a57141f2eefd?w=600&q=80'
  },
  {
    id: 10,
    name: 'Vanilla Cheesecake',
    category: 'Dessert',
    price: '₦4,500',
    description: 'Silky New York style cheesecake with a buttery biscuit base and berry compote.',
    image: 'https://images.unsplash.com/photo-1533134242443-d4fd215305ad?w=600&q=80'
  }
]

const categories = ['All', 'Nigerian', 'Continental', 'Grill', 'Healthy', 'Dessert']

function App() {
  const [activeCategory, setActiveCategory] = useState('All')
  const [mobileOpen, setMobileOpen] = useState(false)
  const [scrolled, setScrolled] = useState(false)
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    date: '',
    guests: '2',
    message: ''
  })
  const [formSubmitted, setFormSubmitted] = useState(false)

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50)
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const filteredMenu = activeCategory === 'All'
    ? menuItems
    : menuItems.filter(item => item.category === activeCategory)

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value })
  }

  const handleSubmit = (e) => {
    e.preventDefault()
    setFormSubmitted(true)
    setTimeout(() => {
      setFormSubmitted(false)
      setFormData({ name: '', email: '', phone: '', date: '', guests: '2', message: '' })
    }, 4000)
  }

  const scrollTo = (id) => {
    setMobileOpen(false)
    document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' })
  }

  return (
    <>
      {/* NAVBAR */}
      <nav className={`navbar ${scrolled ? 'scrolled' : ''}`}>
        <div className="container nav-content">
          <a href="#home" className="logo" onClick={() => scrollTo('home')}>
            Savory <span>House</span>
          </a>

          <ul className={`nav-links ${mobileOpen ? 'open' : ''}`}>
            <li><a href="#home" onClick={() => scrollTo('home')}>Home</a></li>
            <li><a href="#about" onClick={() => scrollTo('about')}>About</a></li>
            <li><a href="#menu" onClick={() => scrollTo('menu')}>Menu</a></li>
            <li><a href="#contact" onClick={() => scrollTo('contact')}>Reservations</a></li>
          </ul>

          <button className="mobile-toggle" onClick={() => setMobileOpen(!mobileOpen)}>
            {mobileOpen ? <X size={24} /> : <Menu size={24} />}
          </button>
        </div>
      </nav>

      {/* HERO */}
      <section className="hero" id="home">
        <div className="hero-content">
          <div className="hero-badge">Fine Dining Experience</div>
          <h1>Welcome to <span>Savory House</span></h1>
          <p>
            Where exceptional flavours meet warm hospitality. Enjoy authentic Nigerian classics, 
            continental favourites and grilled specialties in a refined atmosphere.
          </p>
          <div className="hero-buttons">
            <button className="btn btn-primary" onClick={() => scrollTo('menu')}>
              View Our Menu
            </button>
            <button className="btn btn-outline" onClick={() => scrollTo('contact')}>
              Book a Table
            </button>
          </div>
        </div>
      </section>

      {/* ABOUT */}
      <section className="about" id="about">
        <div className="container">
          <div className="section-header">
            <div className="subtitle">Our Story</div>
            <h2>A Passion for Great Food</h2>
          </div>

          <div className="about-grid">
            <div className="about-image">
              <img 
                src="https://images.unsplash.com/photo-1414235077428-338989a2e8c0?w=800&q=80" 
                alt="Restaurant interior" 
              />
            </div>

            <div className="about-content">
              <h3>Crafted with Love & Excellence</h3>
              <p>
                Savory House was founded with a simple vision — to create a space where people 
                can enjoy outstanding food in a warm, welcoming environment. From the first bite 
                to the last, every dish is prepared with care and the finest ingredients.
              </p>
              <p>
                Whether you're craving spicy Nigerian jollof, a perfectly grilled steak, or a 
                light healthy bowl, our kitchen delivers flavours that leave a lasting impression.
              </p>

              <div className="about-stats">
                <div className="stat">
                  <div className="stat-number">8+</div>
                  <div className="stat-label">Years Experience</div>
                </div>
                <div className="stat">
                  <div className="stat-number">50+</div>
                  <div className="stat-label">Menu Items</div>
                </div>
                <div className="stat">
                  <div className="stat-number">10k+</div>
                  <div className="stat-label">Happy Guests</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* MENU */}
      <section className="menu" id="menu">
        <div className="container">
          <div className="section-header">
            <div className="subtitle">Our Menu</div>
            <h2>Delicious Dishes for Every Taste</h2>
            <p>Explore our carefully curated selection of Nigerian, Continental, Grill, Healthy and Dessert options.</p>
          </div>

          <div className="categories">
            {categories.map(cat => (
              <button
                key={cat}
                className={`category-btn ${activeCategory === cat ? 'active' : ''}`}
                onClick={() => setActiveCategory(cat)}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="menu-grid">
            {filteredMenu.map(item => (
              <div className="menu-card" key={item.id}>
                <div className="menu-card-image">
                  <img src={item.image} alt={item.name} />
                  <span className="menu-card-category">{item.category}</span>
                </div>
                <div className="menu-card-body">
                  <div className="menu-card-header">
                    <h3 className="menu-card-title">{item.name}</h3>
                    <span className="menu-card-price">{item.price}</span>
                  </div>
                  <p className="menu-card-desc">{item.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CONTACT / RESERVATION */}
      <section className="contact" id="contact">
        <div className="container">
          <div className="section-header">
            <div className="subtitle">Reservations</div>
            <h2>Book Your Table</h2>
            <p>We look forward to welcoming you. Reserve your table and enjoy an unforgettable dining experience.</p>
          </div>

          <div className="contact-grid">
            <div className="contact-info">
              <div className="contact-item">
                <div className="contact-icon"><MapPin size={22} /></div>
                <div>
                  <h4>Location</h4>
                  <p>12 Admiralty Way, Lekki Phase 1<br />Lagos, Nigeria</p>
                </div>
              </div>

              <div className="contact-item">
                <div className="contact-icon"><Phone size={22} /></div>
                <div>
                  <h4>Phone</h4>
                  <p>+234 801 234 5678<br />+234 809 876 5432</p>
                </div>
              </div>

              <div className="contact-item">
                <div className="contact-icon"><Mail size={22} /></div>
                <div>
                  <h4>Email</h4>
                  <p>hello@savoryhouse.ng<br />reservations@savoryhouse.ng</p>
                </div>
              </div>

              <div className="contact-item">
                <div className="contact-icon"><Clock size={22} /></div>
                <div>
                  <h4>Opening Hours</h4>
                  <p>Mon – Thu: 11:00 AM – 10:00 PM<br />Fri – Sun: 11:00 AM – 11:30 PM</p>
                </div>
              </div>
            </div>

            <div className="contact-form">
              {formSubmitted ? (
                <div style={{ textAlign: 'center', padding: '40px 20px' }}>
                  <div style={{ fontSize: '3rem', marginBottom: '16px' }}>✓</div>
                  <h3 style={{ color: 'var(--gold)', marginBottom: '12px' }}>Reservation Received!</h3>
                  <p style={{ color: 'rgba(253,248,243,0.8)' }}>
                    Thank you! We'll confirm your booking shortly via email or phone.
                  </p>
                </div>
              ) : (
                <form onSubmit={handleSubmit}>
                  <div className="form-row">
                    <div className="form-group">
                      <label>Full Name</label>
                      <input
                        type="text"
                        name="name"
                        value={formData.name}
                        onChange={handleInputChange}
                        required
                        placeholder="Your name"
                      />
                    </div>
                    <div className="form-group">
                      <label>Email</label>
                      <input
                        type="email"
                        name="email"
                        value={formData.email}
                        onChange={handleInputChange}
                        required
                        placeholder="you@email.com"
                      />
                    </div>
                  </div>

                  <div className="form-row">
                    <div className="form-group">
                      <label>Phone</label>
                      <input
                        type="tel"
                        name="phone"
                        value={formData.phone}
                        onChange={handleInputChange}
                        required
                        placeholder="+234 ..."
                      />
                    </div>
                    <div className="form-group">
                      <label>Date</label>
                      <input
                        type="date"
                        name="date"
                        value={formData.date}
                        onChange={handleInputChange}
                        required
                      />
                    </div>
                  </div>

                  <div className="form-group">
                    <label>Number of Guests</label>
                    <select name="guests" value={formData.guests} onChange={handleInputChange}>
                      {[1,2,3,4,5,6,7,8].map(n => (
                        <option key={n} value={n}>{n} {n === 1 ? 'Guest' : 'Guests'}</option>
                      ))}
                    </select>
                  </div>

                  <div className="form-group">
                    <label>Special Requests (Optional)</label>
                    <textarea
                      name="message"
                      value={formData.message}
                      onChange={handleInputChange}
                      placeholder="Allergies, celebrations, preferred seating..."
                    />
                  </div>

                  <button type="submit" className="submit-btn">
                    Reserve Table
                  </button>
                </form>
              )}
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="footer">
        <div className="container">
          <div className="footer-content">
            <div className="footer-brand">
              <a href="#home" className="logo">Savory <span>House</span></a>
              <p>
                Exceptional food, warm hospitality and unforgettable moments. 
                Join us for an experience that delights every sense.
              </p>
            </div>

            <div>
              <h4>Quick Links</h4>
              <ul>
                <li><a href="#home" onClick={() => scrollTo('home')}>Home</a></li>
                <li><a href="#about" onClick={() => scrollTo('about')}>About Us</a></li>
                <li><a href="#menu" onClick={() => scrollTo('menu')}>Menu</a></li>
                <li><a href="#contact" onClick={() => scrollTo('contact')}>Reservations</a></li>
              </ul>
            </div>

            <div>
              <h4>Menu</h4>
              <ul>
                <li><a href="#menu" onClick={() => { setActiveCategory('Nigerian'); scrollTo('menu') }}>Nigerian</a></li>
                <li><a href="#menu" onClick={() => { setActiveCategory('Continental'); scrollTo('menu') }}>Continental</a></li>
                <li><a href="#menu" onClick={() => { setActiveCategory('Grill'); scrollTo('menu') }}>Grill</a></li>
                <li><a href="#menu" onClick={() => { setActiveCategory('Healthy'); scrollTo('menu') }}>Healthy</a></li>
              </ul>
            </div>

            <div>
              <h4>Contact</h4>
              <ul>
                <li>12 Admiralty Way, Lekki</li>
                <li>+234 801 234 5678</li>
                <li>hello@savoryhouse.ng</li>
              </ul>
            </div>
          </div>

          <div className="footer-bottom">
            <p>© {new Date().getFullYear()} Savory House. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </>
  )
}

export default App
